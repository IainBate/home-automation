"""Core logic modules."""
